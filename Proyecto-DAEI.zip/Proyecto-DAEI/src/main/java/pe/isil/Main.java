package pe.isil;

import pe.isil.dao.DepartmentsDAO;
import pe.isil.model.Departments;

import java.util.List;

public class Main {

    public static void main(String[] args) {
        /*Employees employees = new Employees(74971855, java.sql.Date.valueOf("1994-05-05"), "Mario", "Villa", "M", java.sql.Date.valueOf("2019-10-28"));
        Employees employees1 = new Employees(78361980, java.sql.Date.valueOf("1998-08-19"), "Camila", "Andrade", "F", java.sql.Date.valueOf("2019-09-03"));

        EmployeesDAO.create(employees);
        EmployeesDAO.create(employees1);
        System.out.println("Se ingresó un nuevo empleado: " + employees);
        System.out.println("Se ingresó un nuevo empleado: " + employees1);

        EmployeesDAO employeesDAO = new EmployeesDAO();
        //employeesDAO.update(employees, java.sql.Date.valueOf("2019-09-28"));

        Employees employees2 = EmployeesDAO.findById(74971855);
        System.out.println(employees2);

        List<Employees> employeesList = employeesDAO.findAll();
        System.out.println("Todos los empleados son :" + employeesList);*/

        //EmployeesDAO.delete(employees1);




        /*Departments departments = new Departments("302", "AAA");
        Departments departments1 = new Departments("301", "BBB");


        //DepartmentsDAO.create(departments);
        DepartmentsDAO.create(departments1);
        System.out.println("Se ingresó un nuevo departamento: " + departments);
        System.out.println("Se ingresó un nuevo departamento: " + departments1);

        DepartmentsDAO departmentsDAO = new DepartmentsDAO();
        departmentsDAO.update(departments, "AAA01");

        Departments departments2 = DepartmentsDAO.findById("301");
        System.out.println(departments2);

        List<Departments> departmentsList = departmentsDAO.findAll();
        System.out.println("Todos los departamentos son :" + departmentsList);*/

        //DepartmentsDAO.delete(departments1);



//
//        DepartEmployees departEmployees = new DepartEmployees(74971855, "302", java.sql.Date.valueOf("2019-09-28"), java.sql.Date.valueOf("2019-12-28"));
//        DepartEmployees departEmployees1 = new DepartEmployees(78361980, "301", java.sql.Date.valueOf("2019-09-03"), java.sql.Date.valueOf("2020-02-03"));
//
//
//        //DepartEmployeesDAO.create(departEmployees);
//        DepartEmployeesDAO.create(departEmployees1);
//
//        System.out.println("Se ingresó un nuevo contrato: " + departEmployees);
//        System.out.println("Se ingresó un nuevo contrato: " + departEmployees1);
//
//        DepartEmployeesDAO departEmployeesDAO = new DepartEmployeesDAO();
//        //departEmployeesDAO.update(departEmployees, java.sql.Date.valueOf("2020-01-28"));
//
//        DepartEmployees departEmployees2 = DepartEmployeesDAO.findById(74971855, "302");
//        System.out.println(departEmployees2);
//
//        List<DepartEmployees> departEmployeesList = departEmployeesDAO.findAll();
//        System.out.println("Todos los contratos:" + departEmployeesList);

        //DepartEmployeesDAO.delete(departEmployees1);

//        UserDAO userDAO = new UserDAO();
//
//        User user = userDAO.isValidLogin("isil", "isil");
//        System.out.println("user = " + user);
//

        List<Departments> departmentsList = DepartmentsDAO.findAll();
        System.out.println("Todos los departamentos son :" + departmentsList);

    }

}
