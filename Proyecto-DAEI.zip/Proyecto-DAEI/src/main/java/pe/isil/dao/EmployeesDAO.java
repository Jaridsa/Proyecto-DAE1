package pe.isil.dao;

import pe.isil.model.Employees;
import pe.isil.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmployeesDAO {

    public static Employees create(Employees employees) {
        try (Connection connection = DatabaseUtil.getConnection()) {
            final String sql = "INSERT INTO employees (emp_no, birth_date, first_name, last_name, gender, hire_date) values (?,?,?,?,?,?) ";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1,employees.getEmp_no());
                statement.setDate(2,employees.getBirth_date());
                statement.setString(3,employees.getFirst_name());
                statement.setString(4,employees.getLast_name());
                statement.setString(5,employees.getGender());
                statement.setDate(6,employees.getHire_date());
                statement.executeUpdate();
                return employees;
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }
    public  static void update(Employees employees, Date hire_date) {
        try (Connection connection = DatabaseUtil.getConnection()) {
            final String sql = "UPDATE employees SET hire_date=?  WHERE emp_no=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setDate(1, hire_date);
                statement.setInt(2, employees.getEmp_no());
                statement.executeUpdate();
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }
    public static List<Employees> findAll() {
        List<Employees> employees = new ArrayList<>();
        try (Connection connection = DatabaseUtil.getConnection()) {
            final String sql = "SELECT * FROM employees";
            try (Statement statement = connection.createStatement()) {
                try (ResultSet resultSet = statement.executeQuery(sql)) {
                    while (resultSet.next()) {
                        Employees employee = getEmployee(resultSet);
                        employees.add(employee);
                    }
                }
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
        return employees ;
    }




    public static  void delete(Employees employees) {
        try (Connection connection = DatabaseUtil.getConnection()) {
            final String sql = "DELETE FROM employees  WHERE emp_no=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1,  employees.getEmp_no());
                statement.executeUpdate();
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }


    public static Employees findById(Integer emp_no) {
        Employees employees = null;
        try (Connection connection = DatabaseUtil.getConnection()) {
            final String sql = "SELECT * FROM employees where emp_no=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, emp_no);
                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                        employees = new Employees(
                                resultSet.getInt("emp_no"),
                                resultSet.getDate("birth_date"),
                                resultSet.getString("first_name"),
                                resultSet.getString("last_name"),
                                resultSet.getString("gender"),
                                resultSet.getDate("hire_date")
                        );
                    }
                }
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
        return employees;
    }
    private static Employees getEmployee(ResultSet resultSet) throws SQLException {
        Employees employees = new Employees(
                resultSet.getInt("emp_no"),
                resultSet.getDate("birth_date"),
                resultSet.getString("first_name"),
                resultSet.getString("last_name"),
                resultSet.getString("gender"),
                resultSet.getDate("hire_date")

        );
        return  employees;
    }

}
