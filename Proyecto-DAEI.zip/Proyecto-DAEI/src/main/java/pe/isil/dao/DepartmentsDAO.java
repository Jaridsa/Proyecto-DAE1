package pe.isil.dao;

import pe.isil.model.Departments;
import pe.isil.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DepartmentsDAO {


    public DepartmentsDAO(String jdbcURL, String jdbcUser, String jdbcPassword) {
    }

    public static Departments create(Departments departments) {
        try (Connection connection = DatabaseUtil.getConnection()) {
            final String sql = "INSERT INTO departments (dept_no, dept_name) values (?,?) ";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1,departments.getDept_no());
                statement.setString(2,departments.getDept_name());
                statement.executeUpdate();
                return departments;
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }
    public  static void update(Departments departments, String dept_name) {
        try (Connection connection = DatabaseUtil.getConnection()) {
            final String sql = "UPDATE departments SET dept_name=?  WHERE dept_no=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, dept_name);
                statement.setString(2, departments.getDept_no());
                statement.executeUpdate();
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }
    public static List<Departments> findAll() {
        List<Departments> departments = new ArrayList<>();
        try (Connection connection = DatabaseUtil.getConnection()) {
            final String sql = "SELECT * FROM departments";
            try (Statement statement = connection.createStatement()) {
                try (ResultSet resultSet = statement.executeQuery(sql)) {
                    while (resultSet.next()) {
                        Departments department = getDepartment(resultSet);
                        departments.add(department);
                    }
                }
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
        return departments ;
    }




    public static  void delete(Departments departments) {
        try (Connection connection = DatabaseUtil.getConnection()) {
            final String sql = "DELETE FROM departments  WHERE dept_no=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1,  departments.getDept_no());
                statement.executeUpdate();
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }


    public static Departments findById(String dept_no) {
        Departments departments = null;
        try (Connection connection = DatabaseUtil.getConnection()) {
            final String sql = "SELECT * FROM departments where dept_no=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, dept_no);
                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                        departments = new Departments(
                                resultSet.getString("dept_no"),
                                resultSet.getString("dept_name")
                        );
                    }
                }
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
        return departments;
    }
    private static Departments getDepartment(ResultSet resultSet) throws SQLException {
        Departments departments = new Departments(
                resultSet.getString("dept_no"),
                resultSet.getString("dept_name")

        );
        return  departments;
    }

}
