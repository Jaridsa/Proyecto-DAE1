package pe.isil.dao;

import pe.isil.model.DepartEmployees;
import pe.isil.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DepartEmployeesDAO {

    public static DepartEmployees create(DepartEmployees departEmployees) {
        try (Connection connection = DatabaseUtil.getConnection()) {
            final String sql = "INSERT INTO dept_emp (emp_no, dept_no, from_date, to_date) values (?,?,?,?) ";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1,departEmployees.getEmp_no());
                statement.setString(2,departEmployees.getDept_no());
                statement.setDate(3,departEmployees.getFrom_date());
                statement.setDate(4,departEmployees.getTo_date());
                statement.executeUpdate();
                return departEmployees;
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }
    public  static void update(DepartEmployees departEmployees, Date to_date) {
        try (Connection connection = DatabaseUtil.getConnection()) {
            final String sql = "UPDATE dept_emp SET to_date=?  WHERE emp_no=? and dept_no=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setDate(1, to_date);
                statement.setInt(2, departEmployees.getEmp_no());
                statement.setString(3, departEmployees.getDept_no());
                statement.executeUpdate();
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }
    public static List<DepartEmployees> findAll() {
        List<DepartEmployees> departEmployees = new ArrayList<>();
        try (Connection connection = DatabaseUtil.getConnection()) {
            final String sql = "SELECT * FROM dept_emp";
            try (Statement statement = connection.createStatement()) {
                try (ResultSet resultSet = statement.executeQuery(sql)) {
                    while (resultSet.next()) {
                        DepartEmployees departEmployee = getDepartEmployee(resultSet);
                        departEmployees.add(departEmployee);
                    }
                }
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
        return departEmployees ;
    }




    public static  void delete(DepartEmployees departEmployees) {
        try (Connection connection = DatabaseUtil.getConnection()) {
            final String sql = "DELETE FROM dept_emp  WHERE emp_no=? and dept_no=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1,  departEmployees.getEmp_no());
                statement.setString(2,  departEmployees.getDept_no());
                statement.executeUpdate();
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }


    public static DepartEmployees findById(Integer emp_no, String dept_no) {
        DepartEmployees departEmployees = null;
        try (Connection connection = DatabaseUtil.getConnection()) {
            final String sql = "SELECT * FROM dept_emp where emp_no=? and dept_no=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, emp_no);
                statement.setString(2, dept_no);
                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                        departEmployees = new DepartEmployees(
                                resultSet.getInt("emp_no"),
                                resultSet.getString("dept_no"),
                                resultSet.getDate("from_date"),
                                resultSet.getDate("to_date")
                        );
                    }
                }
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
        return departEmployees;
    }
    private static DepartEmployees getDepartEmployee(ResultSet resultSet) throws SQLException {
        DepartEmployees departEmployees = new DepartEmployees(
                resultSet.getInt("emp_no"),
                resultSet.getString("dept_no"),
                resultSet.getDate("from_date"),
                resultSet.getDate("to_date")

        );
        return  departEmployees;
    }


}
