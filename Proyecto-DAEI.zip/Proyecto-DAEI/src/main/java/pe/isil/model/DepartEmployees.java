package pe.isil.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class DepartEmployees {

    private Integer emp_no;
    private String dept_no;
    private Date from_date;
    private Date to_date;

}
